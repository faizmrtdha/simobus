<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800"><?php echo $title; ?>
        <!--// sama aja kayak < ? php = $title; ?> -->
    </h1>

    <div class="card col-md-4">
        <p id="bus">Pengemudi:<br><?= $nama['bus']; ?></p>
        <div id="autoReloadTabelMentah5"></div>
    </div>

</div>
</div>