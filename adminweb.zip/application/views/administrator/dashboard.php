<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <!-- <h1 class="h3 mb-4 text-gray-800"><?= $title; ?></h1> -->

    <div class="card text-center">
        <div class="card-body">
            <h1 class="card-title text-gray-900">Pembuatan Antarmuka Sistem Monitoring Bus Menggunakan Website</h1>
            <div class="row justify-content-md-center">
                <div class="col col-md-2">
                    <img src="<?= base_url('assets/'); ?>img/logo/pnj.jpg" style="width: 95%; height: 95%">
                </div>
                <div class="col-md-5">

                </div>
                <div class="col col-md-2">
                    <img src="<?= base_url('assets/'); ?>img/logo/bm.png" style="width: 100%; height: 100%">
                </div>
            </div>
        </div>
    </div>
</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->