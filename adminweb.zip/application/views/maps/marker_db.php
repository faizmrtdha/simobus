<?php
$host="localhost";
$username="simobusm_1";
$password="sUtwAam3KYbb";
$database="simobusm_bus";
?>
